# NGINX Sphinx theme

Used to build NGINX documentation with Sphinx.
